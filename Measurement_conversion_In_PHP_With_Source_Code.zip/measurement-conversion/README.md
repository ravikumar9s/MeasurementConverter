# measurement-conversion
Converting measurement project using PHP
1. Length and Distance
2. Area
3. Volume and Capacity
4. Weight and Mass
5. Speed
6. Temperature
